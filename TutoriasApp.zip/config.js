// Configuración
const CONFIG = {
  teacherName: "Tutora: Ina",
  teacherEmail: "ina.osman@educa.madrid.org",
  // Backend (Apps Script) – deja vacío para modo demo
  apiBase: "", // ej. "https://script.google.com/macros/s/AKfycbx.../exec"
  // ¿Cuántos martes mostramos?
  numWeeks: 12
};
